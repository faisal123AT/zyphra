
import { Subject, Level, PaperType, Topic, YearlyPaper, AcademicNote } from './types';

export const SUBJECTS: Subject[] = [
  { id: 'math-d', name: 'Mathematics D', level: Level.OLevel, icon: 'Sigma' },
  { id: 'add-math', name: 'Additional Mathematics', level: Level.OLevel, icon: 'Divide' },
  { id: 'phys-ol', name: 'Physics', level: Level.OLevel, icon: 'Zap' },
  { id: 'chem-ol', name: 'Chemistry', level: Level.OLevel, icon: 'FlaskConical' },
  { id: 'bio-ol', name: 'Biology', level: Level.OLevel, icon: 'Dna' },
  { id: 'bangla-ol', name: 'Bangla', level: Level.OLevel, icon: 'Languages' },
  { id: 'math-as', name: 'AS Mathematics', level: Level.ASLevel, icon: 'Square' },
  { id: 'phys-as', name: 'AS Physics', level: Level.ASLevel, icon: 'Compass' },
];

export const TOPICS: Topic[] = [
  // Mathematics D Topics
  { id: 'm1', subjectId: 'math-d', name: '1 Number', paperType: PaperType.Structured, yearsAvailable: ['2018-2024'] },
  { id: 'm2', subjectId: 'math-d', name: '2 Algebra and graphs', paperType: PaperType.Structured, yearsAvailable: ['2018-2024'] },
  { id: 'm3', subjectId: 'math-d', name: '3 Coordinate geometry', paperType: PaperType.Structured, yearsAvailable: ['2018-2024'] },
  { id: 'm4', subjectId: 'math-d', name: '4 Geometry', paperType: PaperType.Structured, yearsAvailable: ['2018-2024'] },
  { id: 'm5', subjectId: 'math-d', name: '5 Mensuration', paperType: PaperType.Structured, yearsAvailable: ['2018-2024'] },
  { id: 'm6', subjectId: 'math-d', name: '6 Trigonometry', paperType: PaperType.Structured, yearsAvailable: ['2018-2024'] },
  { id: 'm7', subjectId: 'math-d', name: '7 Transformations and vectors', paperType: PaperType.Structured, yearsAvailable: ['2018-2024'] },
  { id: 'm8', subjectId: 'math-d', name: '8 Probability', paperType: PaperType.Structured, yearsAvailable: ['2018-2024'] },
  { id: 'm9', subjectId: 'math-d', name: '9 Statistics', paperType: PaperType.Structured, yearsAvailable: ['2018-2024'] },
  
  // Additional Mathematics Topics
  { id: 'am1', subjectId: 'add-math', name: '1 Functions', paperType: PaperType.Structured, yearsAvailable: ['2018-2024'] },
  { id: 'am2', subjectId: 'add-math', name: '2 Quadratic functions', paperType: PaperType.Structured, yearsAvailable: ['2018-2024'] },
  { id: 'am3', subjectId: 'add-math', name: '3 Factors of polynomials', paperType: PaperType.Structured, yearsAvailable: ['2018-2024'] },
  { id: 'am4', subjectId: 'add-math', name: '4 Equations, inequalities and graphs', paperType: PaperType.Structured, yearsAvailable: ['2018-2024'] },
  { id: 'am5', subjectId: 'add-math', name: '5 Simultaneous equations', paperType: PaperType.Structured, yearsAvailable: ['2018-2024'] },
  { id: 'am6', subjectId: 'add-math', name: '6 Logarithmic and exponential functions', paperType: PaperType.Structured, yearsAvailable: ['2018-2024'] },
  { id: 'am7', subjectId: 'add-math', name: '7 Straight-line graphs', paperType: PaperType.Structured, yearsAvailable: ['2018-2024'] },
  { id: 'am8', subjectId: 'add-math', name: '8 Coordinate geometry of the circle', paperType: PaperType.Structured, yearsAvailable: ['2018-2024'] },
  { id: 'am9', subjectId: 'add-math', name: '9 Circular measure', paperType: PaperType.Structured, yearsAvailable: ['2018-2024'] },
  { id: 'am10', subjectId: 'add-math', name: '10 Trigonometry', paperType: PaperType.Structured, yearsAvailable: ['2018-2024'] },
  { id: 'am11', subjectId: 'add-math', name: '11 Permutations and combinations', paperType: PaperType.Structured, yearsAvailable: ['2018-2024'] },
  { id: 'am12', subjectId: 'add-math', name: '12 Series', paperType: PaperType.Structured, yearsAvailable: ['2018-2024'] },
  { id: 'am13', subjectId: 'add-math', name: '13 Vectors in two dimensions', paperType: PaperType.Structured, yearsAvailable: ['2018-2024'] },
  { id: 'am14', subjectId: 'add-math', name: '14 Calculus', paperType: PaperType.Structured, yearsAvailable: ['2018-2024'] },

  // Physics O Level Topics
  { id: 'p1', subjectId: 'phys-ol', name: '1 Motion, forces and energy', paperType: PaperType.Structured, yearsAvailable: ['2018-2024'] },
  { id: 'p2', subjectId: 'phys-ol', name: '2 Thermal physics', paperType: PaperType.Structured, yearsAvailable: ['2018-2024'] },
  { id: 'p3', subjectId: 'phys-ol', name: '3 Waves', paperType: PaperType.Structured, yearsAvailable: ['2018-2024'] },
  { id: 'p4', subjectId: 'phys-ol', name: '4 Electricity and magnetism', paperType: PaperType.Structured, yearsAvailable: ['2018-2024'] },
  { id: 'p5', subjectId: 'phys-ol', name: '5 Nuclear physics', paperType: PaperType.Structured, yearsAvailable: ['2018-2024'] },
  { id: 'p6', subjectId: 'phys-ol', name: '6 Space physics', paperType: PaperType.Structured, yearsAvailable: ['2018-2024'] },

  // Biology O Level Topics
  { id: 'b1', subjectId: 'bio-ol', name: '1 Cells', paperType: PaperType.Structured, yearsAvailable: ['2018-2024'] },
  { id: 'b2', subjectId: 'bio-ol', name: '2 Classification', paperType: PaperType.Structured, yearsAvailable: ['2018-2024'] },
  { id: 'b3', subjectId: 'bio-ol', name: '3 Movement into and out of cells', paperType: PaperType.Structured, yearsAvailable: ['2018-2024'] },
  { id: 'b4', subjectId: 'bio-ol', name: '4 Biological molecules', paperType: PaperType.Structured, yearsAvailable: ['2018-2024'] },
  { id: 'b5', subjectId: 'bio-ol', name: '5 Enzymes', paperType: PaperType.Structured, yearsAvailable: ['2018-2024'] },
  { id: 'b6', subjectId: 'bio-ol', name: '6 Plant nutrition', paperType: PaperType.Structured, yearsAvailable: ['2018-2024'] },
  { id: 'b7', subjectId: 'bio-ol', name: '7 Transport in flowering plants', paperType: PaperType.Structured, yearsAvailable: ['2018-2024'] },
  { id: 'b8', subjectId: 'bio-ol', name: '8 Human nutrition', paperType: PaperType.Structured, yearsAvailable: ['2018-2024'] },
  { id: 'b9', subjectId: 'bio-ol', name: '9 Human gas exchange', paperType: PaperType.Structured, yearsAvailable: ['2018-2024'] },
  { id: 'b10', subjectId: 'bio-ol', name: '10 Respiration', paperType: PaperType.Structured, yearsAvailable: ['2018-2024'] },
  { id: 'b11', subjectId: 'bio-ol', name: '11 Transport in humans', paperType: PaperType.Structured, yearsAvailable: ['2018-2024'] },
  { id: 'b12', subjectId: 'bio-ol', name: '12 Disease and immunity', paperType: PaperType.Structured, yearsAvailable: ['2018-2024'] },
  { id: 'b13', subjectId: 'bio-ol', name: '13 Excretion', paperType: PaperType.Structured, yearsAvailable: ['2018-2024'] },
  { id: 'b14', subjectId: 'bio-ol', name: '14 Coordination and control', paperType: PaperType.Structured, yearsAvailable: ['2018-2024'] },
  { id: 'b15', subjectId: 'bio-ol', name: '15 Coordination and response in plants', paperType: PaperType.Structured, yearsAvailable: ['2018-2024'] },
  { id: 'b16', subjectId: 'bio-ol', name: '16 Development of organisms and continuity of life', paperType: PaperType.Structured, yearsAvailable: ['2018-2024'] },
  { id: 'b17', subjectId: 'bio-ol', name: '17 Inheritance', paperType: PaperType.Structured, yearsAvailable: ['2018-2024'] },
  { id: 'b18', subjectId: 'bio-ol', name: '18 Biotechnology and genetic modification', paperType: PaperType.Structured, yearsAvailable: ['2018-2024'] },
  { id: 'b19', subjectId: 'bio-ol', name: '19 Relationships of organisms with one another and with the environment', paperType: PaperType.Structured, yearsAvailable: ['2018-2024'] },

  // Chemistry O Level Topics
  { id: 'c1', subjectId: 'chem-ol', name: '1 States of matter', paperType: PaperType.Structured, yearsAvailable: ['2018-2024'] },
  { id: 'c2', subjectId: 'chem-ol', name: '2 Atoms, elements and compounds', paperType: PaperType.Structured, yearsAvailable: ['2018-2024'] },
  { id: 'c3', subjectId: 'chem-ol', name: '3 Stoichiometry', paperType: PaperType.Structured, yearsAvailable: ['2018-2024'] },
  { id: 'c4', subjectId: 'chem-ol', name: '4 Electrochemistry', paperType: PaperType.Structured, yearsAvailable: ['2018-2024'] },
  { id: 'c5', subjectId: 'chem-ol', name: '5 Chemical energetics', paperType: PaperType.Structured, yearsAvailable: ['2018-2024'] },
  { id: 'c6', subjectId: 'chem-ol', name: '6 Chemical reactions', paperType: PaperType.Structured, yearsAvailable: ['2018-2024'] },
  { id: 'c7', subjectId: 'chem-ol', name: '7 Acids, bases and salts', paperType: PaperType.Structured, yearsAvailable: ['2018-2024'] },
  { id: 'c8', subjectId: 'chem-ol', name: '8 The Periodic Table', paperType: PaperType.Structured, yearsAvailable: ['2018-2024'] },
  { id: 'c9', subjectId: 'chem-ol', name: '9 Metals', paperType: PaperType.Structured, yearsAvailable: ['2018-2024'] },
  { id: 'c10', subjectId: 'chem-ol', name: '10 Chemistry of the environment', paperType: PaperType.Structured, yearsAvailable: ['2018-2024'] },
  { id: 'c11', subjectId: 'chem-ol', name: '11 Organic chemistry', paperType: PaperType.Structured, yearsAvailable: ['2018-2024'] },
  { id: 'c12', subjectId: 'chem-ol', name: '12 Experimental techniques and chemical analysis', paperType: PaperType.Structured, yearsAvailable: ['2018-2024'] },

  // AS Mathematics Topics
  { id: 'asm1_1', subjectId: 'math-as', name: '1.1 Quadratics', paperType: PaperType.Structured, yearsAvailable: ['2019-2024'] },
  { id: 'asm1_2', subjectId: 'math-as', name: '1.2 Functions', paperType: PaperType.Structured, yearsAvailable: ['2019-2024'] },
  { id: 'asm1_3', subjectId: 'math-as', name: '1.3 Coordinate geometry', paperType: PaperType.Structured, yearsAvailable: ['2019-2024'] },
  { id: 'asm1_4', subjectId: 'math-as', name: '1.4 Circular measure', paperType: PaperType.Structured, yearsAvailable: ['2019-2024'] },
  { id: 'asm1_5', subjectId: 'math-as', name: '1.5 Trigonometry', paperType: PaperType.Structured, yearsAvailable: ['2019-2024'] },
  { id: 'asm1_6', subjectId: 'math-as', name: '1.6 Series', paperType: PaperType.Structured, yearsAvailable: ['2019-2024'] },
  { id: 'asm1_7', subjectId: 'math-as', name: '1.7 Differentiation', paperType: PaperType.Structured, yearsAvailable: ['2019-2024'] },
  { id: 'asm1_8', subjectId: 'math-as', name: '1.8 Integration', paperType: PaperType.Structured, yearsAvailable: ['2019-2024'] },
  { id: 'asm4_1', subjectId: 'math-as', name: '4.1 Forces and equilibrium', paperType: PaperType.Structured, yearsAvailable: ['2019-2024'] },
  { id: 'asm4_2', subjectId: 'math-as', name: '4.2 Kinematics of motion in a straight line', paperType: PaperType.Structured, yearsAvailable: ['2019-2024'] },
  { id: 'asm4_3', subjectId: 'math-as', name: '4.3 Momentum', paperType: PaperType.Structured, yearsAvailable: ['2019-2024'] },
  { id: 'asm4_4', subjectId: 'math-as', name: '4.4 Newton’s laws of motion', paperType: PaperType.Structured, yearsAvailable: ['2019-2024'] },
  { id: 'asm4_5', subjectId: 'math-as', name: '4.5 Energy, work and power', paperType: PaperType.Structured, yearsAvailable: ['2019-2024'] },

  // AS Physics Topics
  { id: 'asp1', subjectId: 'phys-as', name: '1 Physical quantities and units', paperType: PaperType.Structured, yearsAvailable: ['2019-2024'] },
  { id: 'asp2', subjectId: 'phys-as', name: '2 Kinematics', paperType: PaperType.Structured, yearsAvailable: ['2019-2024'] },
  { id: 'asp3', subjectId: 'phys-as', name: '3 Dynamics', paperType: PaperType.Structured, yearsAvailable: ['2019-2024'] },
  { id: 'asp4', subjectId: 'phys-as', name: '4 Forces, density and pressure', paperType: PaperType.Structured, yearsAvailable: ['2019-2024'] },
  { id: 'asp5', subjectId: 'phys-as', name: '5 Work, energy and power', paperType: PaperType.Structured, yearsAvailable: ['2019-2024'] },
  { id: 'asp6', subjectId: 'phys-as', name: '6 Deformation of solids', paperType: PaperType.Structured, yearsAvailable: ['2019-2024'] },
  { id: 'asp7', subjectId: 'phys-as', name: '7 Waves', paperType: PaperType.Structured, yearsAvailable: ['2019-2024'] },
  { id: 'asp8', subjectId: 'phys-as', name: '8 Superposition', paperType: PaperType.Structured, yearsAvailable: ['2019-2024'] },
  { id: 'asp9', subjectId: 'phys-as', name: '9 Electricity', paperType: PaperType.Structured, yearsAvailable: ['2019-2024'] },
  { id: 'asp10', subjectId: 'phys-as', name: '10 D.C. circuits', paperType: PaperType.Structured, yearsAvailable: ['2019-2024'] },
  { id: 'asp11', subjectId: 'phys-as', name: '11 Particle physics', paperType: PaperType.Structured, yearsAvailable: ['2019-2024'] },
];

export const YEARLY_PAPERS: YearlyPaper[] = [
  { id: 'y1', subjectId: 'math-d', year: 2024, paperNumber: '1', variant: '1', isPremium: true },
  { id: 'y2', subjectId: 'math-d', year: 2023, paperNumber: '2', variant: '2', isPremium: false },
  { id: 'y3', subjectId: 'math-d', year: 2022, paperNumber: '1', variant: '1', isPremium: false },
  { id: 'y4', subjectId: 'math-d', year: 2025, paperNumber: '2', variant: '2', isPremium: true },
];

export const NOTES: AcademicNote[] = [
  {
    id: 'n1',
    subjectId: 'math-d',
    title: 'Circle Theorems Summary',
    content: [
      'Angle at center is twice the angle at circumference.',
      'Angles in same segment are equal.',
      'Angle in a semi-circle is 90 degrees.',
      'Opposite angles in cyclic quadrilateral sum to 180.',
      'Tangent is perpendicular to radius at point of contact.'
    ]
  },
  {
    id: 'n2',
    subjectId: 'phys-ol',
    title: 'Fundamental Physics Constants',
    isFormulaSheet: true,
    content: [
      'Speed of light (c) = 3.00 × 10^8 m/s',
      'Acceleration of free fall (g) = 9.81 m/s^2',
      'Universal gas constant (R) = 8.31 J/(mol·K)',
      'Elementary charge (e) = 1.60 × 10^-19 C'
    ]
  }
];
