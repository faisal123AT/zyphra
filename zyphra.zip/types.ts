
export enum Level {
  OLevel = 'O Level',
  ASLevel = 'AS Level'
}

export enum PaperType {
  MCQ = 'MCQ',
  Structured = 'Structured',
  Theory = 'Theory',
  ATP = 'ATP'
}

export interface Subject {
  id: string;
  name: string;
  level: Level;
  icon: string;
}

export interface Topic {
  id: string;
  subjectId: string;
  name: string;
  paperType: PaperType;
  yearsAvailable: string[];
}

export interface YearlyPaper {
  id: string;
  subjectId: string;
  year: number;
  paperNumber: string;
  variant: string;
  isPremium: boolean;
}

export interface AcademicNote {
  id: string;
  subjectId: string;
  title: string;
  content: string[];
  isFormulaSheet?: boolean;
}

export interface User {
  id: string;
  email: string;
  isPremium: boolean;
  role: 'student' | 'teacher' | 'admin';
  accessedSubjects: string[];
}
