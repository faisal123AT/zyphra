
import React from 'react';
import * as Icons from 'lucide-react';
import { Subject } from '../types';

interface SubjectCardProps {
  subject: Subject;
  onClick: () => void;
  isDarkMode: boolean;
}

const SubjectCard: React.FC<SubjectCardProps> = ({ subject, onClick, isDarkMode }) => {
  const IconComponent = (Icons as any)[subject.icon] || Icons.BookOpen;

  return (
    <div 
      onClick={onClick}
      className={`group cursor-pointer p-8 rounded-2xl border transition-all duration-300 transform hover:-translate-y-1 ${
        isDarkMode 
          ? 'bg-[#151921] border-white/5 hover:border-cyan-500/50 hover:bg-[#1A2029]' 
          : 'bg-white border-black/5 hover:border-cyan-500/30 hover:shadow-xl shadow-sm'
      }`}
    >
      <div className={`w-12 h-12 rounded-xl flex items-center justify-center mb-6 transition-colors ${
        isDarkMode ? 'bg-white/5 group-hover:bg-cyan-500/10' : 'bg-black/5 group-hover:bg-cyan-500/10'
      }`}>
        <IconComponent size={24} className="text-cyan-400" />
      </div>
      <div className="space-y-1">
        <span className={`text-[10px] font-bold tracking-widest uppercase opacity-40`}>
          {subject.level}
        </span>
        <h3 className="text-lg font-semibold tracking-tight">{subject.name}</h3>
      </div>
    </div>
  );
};

export default SubjectCard;
