
import React from 'react';
import { Menu, X, Sun, Moon, LayoutDashboard, Crown, ChevronRight, ChevronDown } from 'lucide-react';

interface NavbarProps {
  isDarkMode: boolean;
  toggleTheme: () => void;
  isLoggedIn: boolean;
  user?: any;
  onNavigate: (page: string, params?: any) => void;
}

const Navbar: React.FC<NavbarProps> = ({ isDarkMode, toggleTheme, isLoggedIn, user, onNavigate }) => {
  const [isOpen, setIsOpen] = React.useState(false);

  const oLevelNotes = [
    { name: 'Bangla', id: 'bangla-ol' },
    { name: 'Biology', id: 'bio-ol' },
    { name: 'Maths-D', id: 'math-d' },
    { name: 'Add-maths', id: 'add-math' },
    { name: 'Physics', id: 'phys-ol' },
    { name: 'Chemistry', id: 'chem-ol' },
  ];

  const aLevelNotes = [
    { name: 'Physics(9702)', id: 'phys-as' },
    { name: 'Maths(9709)', id: 'math-as' },
  ];

  const NestedMenuItem: React.FC<{ name: string; id: string }> = ({ name, id }) => (
    <button
      onClick={() => onNavigate('subject-details', { subjectId: id, initialTab: 'notes' })}
      className={`w-full text-left px-4 py-2 text-xs font-medium transition-colors ${
        isDarkMode ? 'hover:bg-white/5 text-white/70 hover:text-cyan-400' : 'hover:bg-black/5 text-black/70 hover:text-cyan-600'
      }`}
    >
      {name}
    </button>
  );

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 border-b backdrop-blur-md transition-colors duration-300 ${
      isDarkMode ? 'bg-[#0B0F14]/80 border-white/5' : 'bg-white/80 border-black/5'
    }`}>
      <div className="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between">
        <div className="flex items-center gap-12">
          {/* Logo */}
          <button 
            onClick={() => onNavigate('home')}
            className="text-2xl font-bold tracking-tighter text-cyan-400 hover:opacity-80 transition-opacity"
          >
            ZYPHRA
          </button>

          {/* Desktop Links */}
          <div className="hidden md:flex items-center gap-8">
            <button 
              onClick={() => onNavigate('subjects')}
              className={`text-sm font-medium transition-colors hover:text-cyan-400 ${isDarkMode ? 'text-white/70' : 'text-black/70'}`}
            >
              Browse Subjects
            </button>

            <button 
              onClick={() => onNavigate('notes-olevel')}
              className={`text-sm font-medium transition-colors hover:text-cyan-400 ${isDarkMode ? 'text-white/70' : 'text-black/70'}`}
            >
              Browse Notes
            </button>

            {/* Notes Multi-level Dropdown */}
            <div className="relative group">
              <button className={`text-sm font-medium flex items-center gap-1 transition-colors hover:text-cyan-400 ${isDarkMode ? 'text-white/70' : 'text-black/70'}`}>
                Notes Archive <ChevronDown size={14} />
              </button>
              
              {/* First Level Dropdown */}
              <div className={`absolute left-0 top-full pt-2 opacity-0 translate-y-1 pointer-events-none group-hover:opacity-100 group-hover:translate-y-0 group-hover:pointer-events-auto transition-all duration-200`}>
                <div className={`w-48 rounded-xl border shadow-2xl py-2 overflow-hidden ${isDarkMode ? 'bg-[#151921] border-white/10' : 'bg-white border-black/10'}`}>
                  
                  {/* O Level Sub-item */}
                  <div className="relative group/sub">
                    <button 
                      onClick={() => onNavigate('notes-olevel')}
                      className={`w-full px-4 py-2.5 text-sm font-medium flex items-center justify-between transition-colors ${isDarkMode ? 'text-white/70 hover:bg-white/5 hover:text-cyan-400' : 'text-black/70 hover:bg-black/5 hover:text-cyan-600'}`}
                    >
                      O Level <ChevronRight size={14} />
                    </button>
                    {/* Second Level Dropdown: O Level Subjects */}
                    <div className={`absolute left-full top-0 ml-0.5 opacity-0 -translate-x-2 pointer-events-none group-hover/sub:opacity-100 group-hover/sub:translate-x-0 group-hover/sub:pointer-events-auto transition-all duration-200`}>
                      <div className={`w-48 rounded-xl border shadow-2xl py-2 ${isDarkMode ? 'bg-[#151921] border-white/10' : 'bg-white border-black/10'}`}>
                        {oLevelNotes.map(note => (
                          <NestedMenuItem key={note.id} name={note.name} id={note.id} />
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* A Level Sub-item */}
                  <div className="relative group/sub">
                    <button 
                      onClick={() => onNavigate('notes-alevel')}
                      className={`w-full px-4 py-2.5 text-sm font-medium flex items-center justify-between transition-colors ${isDarkMode ? 'text-white/70 hover:bg-white/5 hover:text-cyan-400' : 'text-black/70 hover:bg-black/5 hover:text-cyan-600'}`}
                    >
                      A Level <ChevronRight size={14} />
                    </button>
                    {/* Second Level Dropdown: A Level Subjects */}
                    <div className={`absolute left-full top-0 ml-0.5 opacity-0 -translate-x-2 pointer-events-none group-hover/sub:opacity-100 group-hover/sub:translate-x-0 group-hover/sub:pointer-events-auto transition-all duration-200`}>
                      <div className={`w-48 rounded-xl border shadow-2xl py-2 ${isDarkMode ? 'bg-[#151921] border-white/10' : 'bg-white border-black/10'}`}>
                        {aLevelNotes.map(note => (
                          <NestedMenuItem key={note.id} name={note.name} id={note.id} />
                        ))}
                      </div>
                    </div>
                  </div>

                </div>
              </div>
            </div>

            <button 
              onClick={() => onNavigate('premium')}
              className={`text-sm font-medium flex items-center gap-1.5 transition-colors hover:text-cyan-400 ${isDarkMode ? 'text-white/70' : 'text-black/70'}`}
            >
              <Crown size={14} className="text-violet-400" />
              Premium
            </button>
          </div>
        </div>

        {/* Right Side Actions */}
        <div className="flex items-center gap-4">
          <button 
            onClick={toggleTheme}
            className={`p-2.5 rounded-full transition-colors ${isDarkMode ? 'bg-white/5 text-white hover:bg-white/10' : 'bg-black/5 text-black hover:bg-black/10'}`}
          >
            {isDarkMode ? <Sun size={20} /> : <Moon size={20} />}
          </button>
          
          {isLoggedIn ? (
            <div className="flex items-center gap-3">
              <button 
                onClick={() => onNavigate('dashboard')}
                className={`p-2.5 rounded-full transition-colors ${isDarkMode ? 'bg-white/5 text-white hover:bg-white/10' : 'bg-black/5 text-black hover:bg-black/10'}`}
              >
                <LayoutDashboard size={20} />
              </button>
              <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold text-xs border ${isDarkMode ? 'bg-cyan-500/10 border-cyan-500/20 text-cyan-400' : 'bg-cyan-100 border-cyan-200 text-cyan-600'}`}>
                JD
              </div>
            </div>
          ) : (
            <button 
              onClick={() => onNavigate('auth')}
              className="px-6 py-2.5 bg-white text-black text-sm font-bold rounded-xl hover:bg-cyan-400 hover:text-black transition-all"
            >
              Sign In
            </button>
          )}

          {/* Mobile Menu Toggle */}
          <button 
            onClick={() => setIsOpen(!isOpen)}
            className="md:hidden p-2.5"
          >
            {isOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {isOpen && (
        <div className={`md:hidden border-t animate-in slide-in-from-top-4 duration-300 ${isDarkMode ? 'bg-[#0B0F14] border-white/5' : 'bg-white border-black/5'}`}>
          <div className="p-6 space-y-4">
            <button onClick={() => { onNavigate('subjects'); setIsOpen(false); }} className="block w-full text-left text-lg font-medium">Browse Subjects</button>
            <button onClick={() => { onNavigate('notes-olevel'); setIsOpen(false); }} className="block w-full text-left text-lg font-medium">Browse Notes</button>
            <div className="space-y-2 pt-2">
              <p className="text-xs font-bold text-[#94A3B8] uppercase tracking-wider">Academic Notes</p>
              <div className="pl-4 space-y-2 pt-2">
                <button onClick={() => { onNavigate('notes-olevel'); setIsOpen(false); }} className="block w-full text-left text-sm font-bold text-cyan-400">O Level Catalog</button>
                {oLevelNotes.map(n => (
                  <button key={n.id} onClick={() => { onNavigate('subject-details', { subjectId: n.id, initialTab: 'notes' }); setIsOpen(false); }} className="block w-full text-left text-sm text-[#94A3B8]">{n.name}</button>
                ))}
                <button onClick={() => { onNavigate('notes-alevel'); setIsOpen(false); }} className="block w-full text-left text-sm font-bold text-cyan-400 pt-2">A Level Catalog</button>
                {aLevelNotes.map(n => (
                  <button key={n.id} onClick={() => { onNavigate('subject-details', { subjectId: n.id, initialTab: 'notes' }); setIsOpen(false); }} className="block w-full text-left text-sm text-[#94A3B8]">{n.name}</button>
                ))}
              </div>
            </div>
            <button onClick={() => { onNavigate('premium'); setIsOpen(false); }} className="block w-full text-left text-lg font-medium flex items-center gap-2">
              <Crown size={18} className="text-violet-400" />
              Premium Access
            </button>
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;
