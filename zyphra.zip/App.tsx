
import React from 'react';
import Navbar from './components/Navbar';
import Home from './pages/Home';
import SubjectDetails from './pages/SubjectDetails';
import Auth from './pages/Auth';
import Premium from './pages/Premium';
import NotesCatalog from './pages/NotesCatalog';
import { SUBJECTS } from './data';

const App: React.FC = () => {
  const [page, setPage] = React.useState('home');
  const [pageParams, setPageParams] = React.useState<any>({});
  const [isDarkMode, setIsDarkMode] = React.useState(true);
  const [isLoggedIn, setIsLoggedIn] = React.useState(false);
  const [isPremium, setIsPremium] = React.useState(false);

  const toggleTheme = () => {
    setIsDarkMode(!isDarkMode);
    document.body.classList.toggle('bg-[#0B0F14]', !isDarkMode);
    document.body.classList.toggle('text-[#E2E8F0]', !isDarkMode);
    document.body.classList.toggle('bg-gray-50', isDarkMode);
    document.body.classList.toggle('text-gray-900', isDarkMode);
  };

  const navigate = (newPage: string, params: any = {}) => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
    setPage(newPage);
    setPageParams(params);
  };

  const handleLogin = () => {
    setIsLoggedIn(true);
    navigate('home');
  };

  return (
    <div className={`min-h-screen ${isDarkMode ? 'dark bg-[#0B0F14]' : 'bg-gray-50'}`}>
      <Navbar 
        isDarkMode={isDarkMode} 
        toggleTheme={toggleTheme} 
        isLoggedIn={isLoggedIn}
        onNavigate={navigate}
      />

      <main className="transition-all duration-500">
        {page === 'home' && <Home onNavigate={navigate} isDarkMode={isDarkMode} />}
        
        {page === 'notes-olevel' && <NotesCatalog level="O Level" isDarkMode={isDarkMode} onNavigate={navigate} />}
        {page === 'notes-alevel' && <NotesCatalog level="AS Level" isDarkMode={isDarkMode} onNavigate={navigate} />}

        {page === 'subjects' && (
           <div className="pt-32 pb-20 max-w-7xl mx-auto px-6 space-y-12">
             <div className="space-y-2">
                <h1 className="text-4xl font-bold tracking-tight">Academic Catalog</h1>
                <p className="text-[#94A3B8]">Browse the complete list of O Level & AS Level subjects available on Zyphra.</p>
             </div>
             <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                {SUBJECTS.map(subject => (
                  <div 
                    key={subject.id} 
                    onClick={() => navigate('subject-details', { subjectId: subject.id })}
                    className={`group cursor-pointer p-8 rounded-2xl border transition-all duration-300 transform hover:-translate-y-1 ${
                      isDarkMode 
                        ? 'bg-[#151921] border-white/5 hover:border-cyan-500/50 hover:bg-[#1A2029]' 
                        : 'bg-white border-black/5 hover:border-cyan-500/30 hover:shadow-xl shadow-sm'
                    }`}
                  >
                    <div className="space-y-1">
                      <span className={`text-[10px] font-bold tracking-widest uppercase opacity-40`}>
                        {subject.level}
                      </span>
                      <h3 className="text-lg font-semibold tracking-tight">{subject.name}</h3>
                    </div>
                  </div>
                ))}
             </div>
           </div>
        )}

        {page === 'subject-details' && (
          <SubjectDetails 
            subjectId={pageParams.subjectId} 
            isDarkMode={isDarkMode} 
            onNavigate={navigate} 
            isPremium={isPremium}
          />
        )}

        {page === 'topic-detail' && (
          <div className="pt-32 px-6 max-w-3xl mx-auto text-center space-y-8">
            <h2 className="text-3xl font-bold">Paper View</h2>
            <div className={`aspect-video rounded-3xl border flex flex-col items-center justify-center p-12 ${isDarkMode ? 'bg-[#151921] border-white/5' : 'bg-white border-black/5 shadow-lg'}`}>
              <p className="text-[#94A3B8] mb-6">PDF Document Viewer would render here</p>
              <div className="flex gap-4">
                <button className="px-6 py-2 bg-cyan-500 text-black font-bold rounded-lg hover:bg-cyan-400 transition-all">Download PDF</button>
                <button className="px-6 py-2 border border-white/10 rounded-lg hover:bg-white/5 transition-all">Toggle Answers</button>
              </div>
            </div>
            <button onClick={() => navigate('home')} className="text-cyan-400 font-medium hover:underline">Back to Home</button>
          </div>
        )}

        {page === 'premium' && <Premium isDarkMode={isDarkMode} onNavigate={navigate} />}

        {page === 'auth' && <Auth isDarkMode={isDarkMode} onLogin={handleLogin} />}

        {page === 'dashboard' && (
          <div className="pt-32 pb-20 max-w-7xl mx-auto px-6 space-y-12">
            <div className="flex items-center justify-between">
              <h1 className="text-4xl font-bold tracking-tight">Student Dashboard</h1>
              <div className="flex items-center gap-2 px-4 py-2 bg-white/5 rounded-full border border-white/5">
                <div className={`w-2 h-2 rounded-full ${isPremium ? 'bg-violet-400' : 'bg-cyan-400'}`}></div>
                <span className="text-xs font-bold uppercase tracking-widest">{isPremium ? 'Premium User' : 'Standard User'}</span>
              </div>
            </div>

            <div className="grid md:grid-cols-3 gap-8">
              <div className={`col-span-2 p-10 rounded-3xl border ${isDarkMode ? 'bg-[#151921] border-white/5' : 'bg-white border-black/5'}`}>
                <h3 className="text-xl font-bold mb-6">Recent Activity</h3>
                <div className="space-y-4">
                  {[
                    { title: 'Mathematics D Paper 2 - 2023', time: '2 hours ago' },
                    { title: 'Physics Topical: Kinematics', time: 'Yesterday' },
                    { title: 'AS Mathematics Formula Sheet', time: '3 days ago' }
                  ].map((item, idx) => (
                    <div key={idx} className="flex items-center justify-between p-4 rounded-xl hover:bg-white/5 transition-all group cursor-pointer">
                      <span className="text-sm">{item.title}</span>
                      <span className="text-xs text-[#94A3B8]">{item.time}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className={`p-10 rounded-3xl border ${isDarkMode ? 'bg-[#151921] border-white/5' : 'bg-white border-black/5'}`}>
                <h3 className="text-xl font-bold mb-6">Saved Subjects</h3>
                <div className="space-y-3">
                  {SUBJECTS.slice(0, 3).map(s => (
                    <div key={s.id} className="p-3 rounded-lg border border-white/5 text-sm font-medium hover:border-cyan-500/50 transition-all cursor-pointer">
                      {s.name}
                    </div>
                  ))}
                </div>
                {!isPremium && (
                  <button 
                    onClick={() => navigate('premium')}
                    className="w-full mt-10 py-3 bg-violet-500 text-white font-bold rounded-xl hover:bg-violet-400 transition-all text-sm"
                  >
                    Upgrade to Premium
                  </button>
                )}
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Global Footer */}
      <footer className={`py-12 border-t mt-20 ${isDarkMode ? 'bg-[#0B0F14] border-white/5' : 'bg-white border-black/5'}`}>
        <div className="max-w-7xl mx-auto px-6 flex flex-col md:flex-row justify-between items-center gap-8">
          <div className="text-xl font-bold tracking-tight text-cyan-400">ZYPHRA</div>
          <div className="flex gap-8 text-sm text-[#94A3B8]">
            <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-white transition-colors">Terms of Service</a>
            <a href="#" className="hover:text-white transition-colors">Contact Admin</a>
          </div>
          <p className="text-xs text-[#94A3B8]">© 2024 Zyphra Education. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
};

export default App;
