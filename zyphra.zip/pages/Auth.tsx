
import React from 'react';
import { Mail, Lock, ArrowRight } from 'lucide-react';

interface AuthProps {
  isDarkMode: boolean;
  onLogin: () => void;
}

const Auth: React.FC<AuthProps> = ({ isDarkMode, onLogin }) => {
  const [isSignUp, setIsSignUp] = React.useState(false);

  return (
    <div className="min-h-screen flex items-center justify-center px-6 pt-20">
      <div className={`w-full max-w-md p-10 rounded-3xl border ${isDarkMode ? 'bg-[#151921] border-white/5' : 'bg-white border-black/5 shadow-sm'}`}>
        <div className="text-center mb-10 space-y-2">
          <h2 className="text-2xl font-bold tracking-tight">{isSignUp ? 'Join Zyphra' : 'Welcome back'}</h2>
          <p className="text-sm text-[#94A3B8]">The elite platform for O Level & AS Level</p>
        </div>

        <form className="space-y-4" onSubmit={(e) => { e.preventDefault(); onLogin(); }}>
          <div className="space-y-1.5">
            <label className="text-xs font-bold uppercase tracking-wider text-[#94A3B8] ml-1">Email Address</label>
            <div className="relative">
              <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-[#94A3B8]" size={18} />
              <input 
                type="email" 
                placeholder="topper@university.edu"
                className={`w-full py-4 pl-12 pr-4 rounded-xl border focus:outline-none focus:ring-2 focus:ring-cyan-500/50 transition-all ${
                  isDarkMode ? 'bg-white/5 border-white/5 text-white' : 'bg-black/5 border-black/5 text-black'
                }`}
              />
            </div>
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-bold uppercase tracking-wider text-[#94A3B8] ml-1">Password</label>
            <div className="relative">
              <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-[#94A3B8]" size={18} />
              <input 
                type="password" 
                placeholder="••••••••"
                className={`w-full py-4 pl-12 pr-4 rounded-xl border focus:outline-none focus:ring-2 focus:ring-cyan-500/50 transition-all ${
                  isDarkMode ? 'bg-white/5 border-white/5 text-white' : 'bg-black/5 border-black/5 text-black'
                }`}
              />
            </div>
          </div>

          {!isSignUp && (
            <div className="text-right">
              <button type="button" className="text-xs font-medium text-cyan-400 hover:underline">Forgot password?</button>
            </div>
          )}

          <button 
            type="submit"
            className="w-full py-4 bg-cyan-500 text-black font-bold rounded-xl hover:bg-cyan-400 transition-all flex items-center justify-center gap-2 group"
          >
            {isSignUp ? 'Create Account' : 'Sign In'}
            <ArrowRight size={18} className="group-hover:translate-x-1 transition-transform" />
          </button>
        </form>

        <div className="mt-8 text-center text-sm text-[#94A3B8]">
          {isSignUp ? 'Already have an account?' : "Don't have an account?"}{' '}
          <button 
            onClick={() => setIsSignUp(!isSignUp)}
            className="text-cyan-400 font-bold hover:underline"
          >
            {isSignUp ? 'Sign In' : 'Sign Up'}
          </button>
        </div>
      </div>
    </div>
  );
};

export default Auth;
