
import React from 'react';
import { BookOpen, Languages, Zap, FlaskConical, Dna, Square, Divide, Sigma, ArrowRight } from 'lucide-react';

interface NotesCatalogProps {
  level: 'O Level' | 'AS Level';
  isDarkMode: boolean;
  onNavigate: (page: string, params?: any) => void;
}

// Added CatalogSubject interface to handle optional subTitle property
interface CatalogSubject {
  name: string;
  id: string;
  icon: React.ElementType;
  color: string;
  subTitle?: string;
}

const NotesCatalog: React.FC<NotesCatalogProps> = ({ level, isDarkMode, onNavigate }) => {
  const oLevelSubjects: CatalogSubject[] = [
    { name: 'Bangla', id: 'bangla-ol', icon: Languages, color: 'text-rose-400' },
    { name: 'Biology', id: 'bio-ol', icon: Dna, color: 'text-emerald-400' },
    { name: 'Mathematics D', id: 'math-d', icon: Sigma, color: 'text-cyan-400' },
    { name: 'Additional Mathematics', id: 'add-math', icon: Divide, color: 'text-amber-400' },
    { name: 'Physics', id: 'phys-ol', icon: Zap, color: 'text-blue-400' },
    { name: 'Chemistry', id: 'chem-ol', icon: FlaskConical, color: 'text-purple-400' },
  ];

  const aLevelSubjects: CatalogSubject[] = [
    { name: 'Physics(9702)', id: 'phys-as', icon: Zap, color: 'text-blue-400' },
    { name: 'Maths (P-01)', id: 'math-as', icon: Square, color: 'text-cyan-400', subTitle: 'Pure Mathematics 1' },
    { name: 'Maths (M-01)', id: 'math-as', icon: Square, color: 'text-rose-400', subTitle: 'Mechanics 1' },
  ];

  const subjects = level === 'O Level' ? oLevelSubjects : aLevelSubjects;

  return (
    <div className="pt-32 pb-20 px-6 max-w-7xl mx-auto space-y-12">
      <div className="space-y-4 animate-in fade-in slide-in-from-top-4 duration-500">
        <span className="text-[10px] font-bold tracking-widest text-cyan-400 uppercase">{level} Notes Archive</span>
        <h1 className="text-4xl md:text-5xl font-bold tracking-tight">Academic Resources</h1>
        <p className="text-[#94A3B8] max-w-2xl leading-relaxed">
          Access meticulously crafted notes, formula sheets, and solved examples designed for maximum performance in your {level} examinations.
        </p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {subjects.map((subject, idx) => {
          const Icon = subject.icon;
          return (
            <div 
              key={`${subject.id}-${idx}`}
              onClick={() => onNavigate('subject-details', { subjectId: subject.id, initialTab: 'notes' })}
              className={`group relative p-8 rounded-3xl border transition-all duration-500 cursor-pointer overflow-hidden ${
                isDarkMode 
                  ? 'bg-[#151921] border-white/5 hover:border-cyan-500/50 hover:bg-[#1A2029]' 
                  : 'bg-white border-black/5 hover:border-cyan-500/30 hover:shadow-2xl'
              }`}
            >
              {/* Animated Glow */}
              <div className="absolute -top-24 -right-24 w-48 h-48 bg-cyan-500/5 rounded-full blur-[80px] group-hover:bg-cyan-500/10 transition-all duration-500" />
              
              <div className="relative z-10 space-y-6">
                <div className={`w-14 h-14 rounded-2xl flex items-center justify-center transition-transform duration-500 group-hover:scale-110 ${isDarkMode ? 'bg-white/5' : 'bg-black/5'}`}>
                  <Icon size={28} className={subject.color} />
                </div>
                
                <div className="space-y-1">
                  <h3 className="text-xl font-bold tracking-tight">{subject.name}</h3>
                  {/* Fixed Property 'subTitle' does not exist error by using the CatalogSubject interface */}
                  {subject.subTitle && (
                    <p className="text-xs text-[#94A3B8] font-medium">{subject.subTitle}</p>
                  )}
                  <p className="text-sm text-[#94A3B8]/60 pt-2 flex items-center gap-2 group-hover:text-cyan-400 transition-colors">
                    View Archive <ArrowRight size={14} className="group-hover:translate-x-1 transition-transform" />
                  </p>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default NotesCatalog;
