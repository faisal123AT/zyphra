
import React from 'react';
import { ArrowRight, ShieldCheck, Clock, FileCheck, BookOpen } from 'lucide-react';
import SubjectCard from '../components/SubjectCard';
import { SUBJECTS } from '../data';

interface HomeProps {
  onNavigate: (page: string, params?: any) => void;
  isDarkMode: boolean;
}

const Home: React.FC<HomeProps> = ({ onNavigate, isDarkMode }) => {
  return (
    <div className="pt-32 pb-20 space-y-32">
      {/* Hero Section */}
      <section className="max-w-5xl mx-auto px-6 text-center space-y-8 animate-in fade-in slide-in-from-bottom-8 duration-700">
        <h1 className="text-5xl md:text-7xl font-bold tracking-tight leading-[1.1]">
          Structured learning.<br />
          <span className="text-cyan-400">Proven results.</span>
        </h1>
        <p className="text-lg md:text-xl text-[#94A3B8] max-w-2xl mx-auto leading-relaxed font-light">
          Solved topical papers, yearly papers, and concise notes — meticulously built for O Level and AS success by those who've been there.
        </p>
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-4">
          <button 
            onClick={() => onNavigate('subjects')}
            className="w-full sm:w-auto px-8 py-4 bg-cyan-500 text-black font-bold rounded-xl hover:bg-cyan-400 transition-all hover:shadow-[0_0_25px_rgba(34,211,238,0.2)] flex items-center justify-center gap-2 group"
          >
            Browse Subjects
            <ArrowRight size={18} className="group-hover:translate-x-1 transition-transform" />
          </button>
          
          <button 
            onClick={() => onNavigate('notes-olevel')}
            className="w-full sm:w-auto px-8 py-4 bg-cyan-500 text-black font-bold rounded-xl hover:bg-cyan-400 transition-all hover:shadow-[0_0_25px_rgba(34,211,238,0.2)] flex items-center justify-center gap-2 group"
          >
            Browse Notes
            <BookOpen size={18} className="group-hover:scale-110 transition-transform" />
          </button>

          <button 
            onClick={() => onNavigate('auth')}
            className={`w-full sm:w-auto px-8 py-4 font-bold rounded-xl border transition-all ${
              isDarkMode ? 'border-white/10 hover:bg-white/5' : 'border-black/10 hover:bg-black/5'
            }`}
          >
            Create Account
          </button>
        </div>
      </section>

      {/* Trust Section */}
      <section className="max-w-7xl mx-auto px-6">
        <div className={`grid md:grid-cols-3 gap-12 p-12 rounded-3xl border ${isDarkMode ? 'bg-[#151921]/50 border-white/5' : 'bg-gray-50 border-black/5'}`}>
          <div className="space-y-4">
            <ShieldCheck size={28} className="text-cyan-400" />
            <h4 className="font-semibold text-lg">Verified Content</h4>
            <p className="text-sm text-[#94A3B8] leading-relaxed">Admin & verified-teacher reviewed material ensures the highest academic accuracy for your exams.</p>
          </div>
          <div className="space-y-4">
            <Clock size={28} className="text-violet-400" />
            <h4 className="font-semibold text-lg">Always Current</h4>
            <p className="text-sm text-[#94A3B8] leading-relaxed">Regularly updated with the latest exam patterns and marking schemes for global curriculum alignment.</p>
          </div>
          <div className="space-y-4">
            <FileCheck size={28} className="text-cyan-400" />
            <h4 className="font-semibold text-lg">Exam Focused</h4>
            <p className="text-sm text-[#94A3B8] leading-relaxed">Designed specifically for O Level & AS students worldwide, stripping away the fluff to focus on core concepts.</p>
          </div>
        </div>
      </section>

      {/* Subjects Preview */}
      <section className="max-w-7xl mx-auto px-6 space-y-12">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
          <div className="space-y-2">
            <h2 className="text-3xl font-bold tracking-tight">Core Curriculum</h2>
            <p className="text-[#94A3B8]">Select a subject to explore papers, notes, and formula sheets.</p>
          </div>
          <button 
            onClick={() => onNavigate('subjects')}
            className="text-cyan-400 font-medium hover:underline flex items-center gap-2"
          >
            View all subjects <ArrowRight size={16} />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {SUBJECTS.slice(0, 4).map(subject => (
            <SubjectCard 
              key={subject.id} 
              subject={subject} 
              isDarkMode={isDarkMode}
              onClick={() => onNavigate('subject-details', { subjectId: subject.id })} 
            />
          ))}
        </div>
      </section>
    </div>
  );
};

export default Home;
