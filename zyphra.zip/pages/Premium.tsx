
import React from 'react';
import { Check, Shield, Zap, Sparkles, Crown } from 'lucide-react';

interface PremiumProps {
  isDarkMode: boolean;
  onNavigate: (page: string) => void;
}

const Premium: React.FC<PremiumProps> = ({ isDarkMode, onNavigate }) => {
  return (
    <div className="pt-32 pb-20 px-6 max-w-5xl mx-auto space-y-16">
      <div className="text-center space-y-4 max-w-2xl mx-auto">
        <h1 className="text-4xl md:text-5xl font-bold tracking-tight">Access everything.</h1>
        <p className="text-[#94A3B8] text-lg">One plan. Complete access to O Level and AS archives from 2018 to 2026.</p>
      </div>

      <div className="grid md:grid-cols-2 gap-8">
        {/* Free Plan */}
        <div className={`p-10 rounded-3xl border flex flex-col justify-between ${isDarkMode ? 'bg-[#151921] border-white/5' : 'bg-white border-black/5 shadow-sm'}`}>
          <div className="space-y-8">
            <div className="space-y-2">
              <h3 className="text-xl font-bold">Standard</h3>
              <p className="text-3xl font-bold">Free</p>
            </div>
            <ul className="space-y-4">
              {[
                'Access years 2019-2023',
                'General topical papers',
                'Basic academic notes',
                'Standard formula sheets',
                'Global support access'
              ].map((item, idx) => (
                <li key={idx} className="flex items-center gap-3 text-sm text-[#94A3B8]">
                  <Check size={16} className="text-cyan-400" />
                  {item}
                </li>
              ))}
            </ul>
          </div>
          <button 
            onClick={() => onNavigate('auth')}
            className={`w-full mt-10 py-4 rounded-xl font-bold border transition-all ${
              isDarkMode ? 'border-white/10 hover:bg-white/5' : 'border-black/10 hover:bg-black/5'
            }`}
          >
            Stay Standard
          </button>
        </div>

        {/* Premium Plan */}
        <div className={`relative p-10 rounded-3xl border-2 flex flex-col justify-between overflow-hidden ${
          isDarkMode ? 'bg-[#1A2029] border-cyan-500/50' : 'bg-white border-cyan-500/30 shadow-xl'
        }`}>
          <div className="absolute top-0 right-0 p-6 opacity-10">
            <Crown size={120} />
          </div>
          
          <div className="space-y-8 relative z-10">
            <div className="space-y-2">
              <div className="flex items-center gap-2 text-cyan-400 font-bold text-xs uppercase tracking-widest">
                <Sparkles size={14} />
                Recommended
              </div>
              <h3 className="text-xl font-bold">Premium</h3>
              <p className="text-3xl font-bold">$12.99 <span className="text-base font-normal text-[#94A3B8]">/ yearly</span></p>
            </div>
            <ul className="space-y-4">
              {[
                'Unlock years 2018-2026',
                'Premium topical papers',
                'Expert-curated short notes',
                'Print-ready formula sheets',
                'Priority marking scheme updates',
                'Ad-free expert experience'
              ].map((item, idx) => (
                <li key={idx} className="flex items-center gap-3 text-sm text-cyan-400">
                  <Check size={16} />
                  <span className={isDarkMode ? 'text-white' : 'text-black'}>{item}</span>
                </li>
              ))}
            </ul>
          </div>
          <button 
            className="w-full mt-10 py-4 rounded-xl font-bold bg-cyan-500 text-black hover:bg-cyan-400 transition-all hover:shadow-[0_0_25px_rgba(34,211,238,0.3)] relative z-10"
          >
            Upgrade Now
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-8 pt-10">
        <div className="text-center space-y-2">
          <Shield size={24} className="mx-auto text-[#94A3B8]" />
          <p className="text-xs font-medium text-[#94A3B8] uppercase">Secure Billing</p>
        </div>
        <div className="text-center space-y-2">
          <Zap size={24} className="mx-auto text-[#94A3B8]" />
          <p className="text-xs font-medium text-[#94A3B8] uppercase">Instant Access</p>
        </div>
        <div className="text-center space-y-2">
          <Sparkles size={24} className="mx-auto text-[#94A3B8]" />
          <p className="text-xs font-medium text-[#94A3B8] uppercase">Elite Quality</p>
        </div>
      </div>
    </div>
  );
};

export default Premium;
