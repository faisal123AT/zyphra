
import React from 'react';
import { ChevronRight, FileText, BookOpen, Download, Lock, CheckCircle2 } from 'lucide-react';
import { SUBJECTS, TOPICS, YEARLY_PAPERS, NOTES } from '../data';
import { PaperType } from '../types';

interface SubjectDetailsProps {
  subjectId: string;
  isDarkMode: boolean;
  onNavigate: (page: string, params?: any) => void;
  isPremium: boolean;
}

const SubjectDetails: React.FC<SubjectDetailsProps> = ({ subjectId, isDarkMode, onNavigate, isPremium }) => {
  const [activeTab, setActiveTab] = React.useState<'topical' | 'yearly' | 'notes' | 'formula'>('topical');
  const subject = SUBJECTS.find(s => s.id === subjectId);

  if (!subject) return <div className="pt-32 text-center">Subject not found.</div>;

  const subjectTopics = TOPICS.filter(t => t.subjectId === subjectId);
  const yearlyPapers = YEARLY_PAPERS.filter(p => p.subjectId === subjectId).sort((a, b) => b.year - a.year);
  const subjectNotes = NOTES.filter(n => n.subjectId === subjectId && !n.isFormulaSheet);
  const formulaSheets = NOTES.filter(n => n.subjectId === subjectId && n.isFormulaSheet);

  return (
    <div className="pt-32 pb-20 max-w-5xl mx-auto px-6">
      {/* Breadcrumbs */}
      <nav className="flex items-center gap-2 text-sm text-[#94A3B8] mb-8">
        <button onClick={() => onNavigate('home')} className="hover:text-white transition-colors">Home</button>
        <ChevronRight size={14} />
        <button onClick={() => onNavigate('subjects')} className="hover:text-white transition-colors">Subjects</button>
        <ChevronRight size={14} />
        <span className="text-cyan-400 font-medium">{subject.name}</span>
      </nav>

      {/* Header */}
      <div className="mb-12 space-y-2">
        <span className="text-[10px] font-bold tracking-widest text-cyan-400 uppercase">{subject.level}</span>
        <h1 className="text-4xl font-bold tracking-tight">{subject.name}</h1>
      </div>

      {/* Custom Tabs */}
      <div className={`flex gap-1 p-1 rounded-xl mb-12 overflow-x-auto custom-scrollbar ${isDarkMode ? 'bg-white/5' : 'bg-black/5'}`}>
        {(['topical', 'yearly', 'notes', 'formula'] as const).map(tab => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`px-6 py-2.5 rounded-lg text-sm font-medium transition-all whitespace-nowrap ${
              activeTab === tab 
                ? (isDarkMode ? 'bg-white/10 text-white shadow-sm' : 'bg-white text-black shadow-sm')
                : 'text-[#94A3B8] hover:text-white'
            }`}
          >
            {tab.charAt(0).toUpperCase() + tab.slice(1)} Papers
          </button>
        ))}
      </div>

      {/* Tab Content */}
      <div className="space-y-6 animate-in fade-in duration-500">
        {activeTab === 'topical' && (
          <div className="space-y-4">
            {subjectTopics.length > 0 ? subjectTopics.map(topic => (
              <div 
                key={topic.id}
                className={`p-6 rounded-2xl border flex items-center justify-between transition-all ${
                  isDarkMode ? 'bg-[#151921] border-white/5 hover:bg-[#1A2029]' : 'bg-white border-black/5 hover:shadow-md'
                }`}
              >
                <div className="space-y-1">
                  <h3 className="font-semibold">{topic.name}</h3>
                  <div className="flex items-center gap-3 text-xs text-[#94A3B8]">
                    <span className={`px-2 py-0.5 rounded-full ${isDarkMode ? 'bg-white/5' : 'bg-black/5'}`}>
                      {topic.paperType}
                    </span>
                    <span>Years: {topic.yearsAvailable.join(', ')}</span>
                  </div>
                </div>
                <button 
                  onClick={() => onNavigate('topic-detail', { topicId: topic.id })}
                  className="p-3 bg-white/5 rounded-xl hover:bg-cyan-500 hover:text-black transition-all"
                >
                  <ChevronRight size={18} />
                </button>
              </div>
            )) : (
              <p className="text-center py-12 text-[#94A3B8]">No topical papers available for this subject yet.</p>
            )}
          </div>
        )}

        {activeTab === 'yearly' && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {yearlyPapers.map(paper => (
              <div 
                key={paper.id}
                className={`p-6 rounded-2xl border flex items-center justify-between transition-all ${
                  isDarkMode ? 'bg-[#151921] border-white/5' : 'bg-white border-black/5'
                }`}
              >
                <div className="flex items-center gap-4">
                  <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${isDarkMode ? 'bg-white/5' : 'bg-black/5'}`}>
                    <FileText size={18} className="text-cyan-400" />
                  </div>
                  <div>
                    <h4 className="font-medium">{paper.year} Paper {paper.paperNumber}</h4>
                    <span className="text-xs text-[#94A3B8]">Variant {paper.variant}</span>
                  </div>
                </div>
                
                {paper.isPremium && !isPremium ? (
                  <button 
                    onClick={() => onNavigate('premium')}
                    className="flex items-center gap-2 px-4 py-2 text-xs font-bold bg-violet-500/10 text-violet-400 border border-violet-500/20 rounded-lg hover:bg-violet-500 hover:text-white transition-all"
                  >
                    <Lock size={12} />
                    Unlock
                  </button>
                ) : (
                  <button className="p-2 hover:bg-cyan-500/10 rounded-lg transition-colors group">
                    <Download size={18} className="group-hover:text-cyan-400" />
                  </button>
                )}
              </div>
            ))}
          </div>
        )}

        {activeTab === 'notes' && (
          <div className="space-y-4">
             {subjectNotes.length > 0 ? subjectNotes.map(note => (
              <div 
                key={note.id}
                className={`p-8 rounded-3xl border ${isDarkMode ? 'bg-[#151921] border-white/5' : 'bg-white border-black/5'}`}
              >
                <div className="flex justify-between items-start mb-6">
                  <h3 className="text-xl font-bold">{note.title}</h3>
                  <button className="flex items-center gap-2 text-xs font-medium text-cyan-400 hover:opacity-70">
                    <Download size={14} /> PDF
                  </button>
                </div>
                <ul className="space-y-3">
                  {note.content.map((point, idx) => (
                    <li key={idx} className="flex gap-3 text-sm text-[#94A3B8] leading-relaxed">
                      <CheckCircle2 size={16} className="text-cyan-400 shrink-0 mt-0.5" />
                      {point}
                    </li>
                  ))}
                </ul>
              </div>
            )) : (
              <p className="text-center py-12 text-[#94A3B8]">Notes coming soon.</p>
            )}
          </div>
        )}

        {activeTab === 'formula' && (
           <div className="space-y-4">
           {formulaSheets.length > 0 ? formulaSheets.map(note => (
            <div 
              key={note.id}
              className={`p-8 rounded-3xl border ${isDarkMode ? 'bg-[#151921] border-white/5' : 'bg-white border-black/5'}`}
            >
              <div className="flex justify-between items-start mb-6">
                <h3 className="text-xl font-bold">{note.title}</h3>
                <button className="flex items-center gap-2 text-xs font-medium text-cyan-400 hover:opacity-70">
                  <Download size={14} /> PDF
                </button>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {note.content.map((point, idx) => (
                  <div key={idx} className={`p-4 rounded-xl border ${isDarkMode ? 'bg-white/5 border-white/5' : 'bg-black/5 border-black/5'}`}>
                    <p className="text-sm font-mono text-cyan-400">{point}</p>
                  </div>
                ))}
              </div>
            </div>
          )) : (
            <p className="text-center py-12 text-[#94A3B8]">Formula sheets coming soon.</p>
          )}
        </div>
        )}
      </div>
    </div>
  );
};

export default SubjectDetails;
